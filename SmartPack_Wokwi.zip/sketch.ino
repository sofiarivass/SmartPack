// Declaración de librerias a utilizar
#include <Wire.h>
#include <HX711.h>
#include <hd44780.h>
#include <hd44780ioClass/hd44780_I2Cexp.h>

// Pantalla LCD I2C
hd44780_I2Cexp lcd;

// Celda de carga HX711
HX711 scale;

// Declaración de Pines de los sensores ultrasónicos
const int TRIG_LARGO = 7;
const int ECHO_LARGO = 6;

const int TRIG_ANCHO = 5;
const int ECHO_ANCHO = 4;

const int TRIG_ALTO = 3;
const int ECHO_ALTO = 2;

// Pines del HX711
const int PIN_HX_DT = A0;
const int PIN_HX_SCK = A1;

// Declaración de LEDs de estado
const int PIN_LED_VERDE = 11;
const int PIN_LED_ROJO = 12;

// Declaración del Factor de calibración (convierte la lectura directa a kg)
const float FACTOR_CALIBRACION = 420.0;

// Declaración de Límites de peso máximo y mínimo de la estación
const float LIMITE_PESO_MAX_KG = 10.0;
const float LIMITE_DIMENSION_MAX_CM = 70.0;

unsigned long tiempoPantalla = 0;
int pagina = 0;

// Función para medir distancia en cm con el HC-SR04
float medirDistancia(int trig, int echo) {
  digitalWrite(trig, LOW);
  delayMicroseconds(2);

  digitalWrite(trig, HIGH);
  delayMicroseconds(10);
  digitalWrite(trig, LOW);

  long duracion = pulseIn(echo, HIGH, 30000); // Timeout de 30ms

  if (duracion == 0) {
    return 0.0;
  }

  return (duracion * 0.034 / 2.0);
}

// funcion de inicialización del sistema
void setup() {
  Serial.begin(9600);

  // Configuración de pines de ultrasonido
  pinMode(TRIG_LARGO, OUTPUT);
  pinMode(ECHO_LARGO, INPUT);

  pinMode(TRIG_ANCHO, OUTPUT);
  pinMode(ECHO_ANCHO, INPUT);

  pinMode(TRIG_ALTO, OUTPUT);
  pinMode(ECHO_ALTO, INPUT);

  // Configuración de pines de LEDs
  pinMode(PIN_LED_VERDE, OUTPUT);
  pinMode(PIN_LED_ROJO, OUTPUT);

  // Inicialización del módulo HX711
  scale.begin(PIN_HX_DT, PIN_HX_SCK);
  scale.set_scale(FACTOR_CALIBRACION);
  scale.set_offset(0);

  // Inicialización de la pantalla LCD
  lcd.begin(16, 2);
  lcd.setCursor(0, 0);
  lcd.print("Estacion Correo");
  lcd.setCursor(0, 1);
  lcd.print("Iniciando...");
  delay(1500);
  lcd.clear();
}

// funcion principal del sistema
void loop() {
  // 1. Medir dimensiones en tiempo real (cm)
  float largo = medirDistancia(TRIG_LARGO, ECHO_LARGO);
  delay(15);

  float ancho = medirDistancia(TRIG_ANCHO, ECHO_ANCHO);
  delay(15);

  float alto = medirDistancia(TRIG_ALTO, ECHO_ALTO);
  delay(15);

    // 2. Lectura del peso desde el HX711 (modo diagnóstico)
  long raw = scale.read();                 // lectura cruda, sin tare ni escala
  float pesoKg = scale.get_units(1);       // lectura con tare y factor

  Serial.print("raw=");
  Serial.print(raw);
  Serial.print(" units=");
  Serial.println(pesoKg);

  if (pesoKg < 0) pesoKg = 0.0;

  // 3. Lógica de clasificación por peso y dimensiones
  String categoria = "EXCESO";
  String catCorta = "EXC";
  int tarifa = 0;

  bool medicionValida = (largo > 0 && ancho > 0 && alto > 0);

  if (medicionValida) {
    if (pesoKg <= 2.0 && largo <= 20.0 && ancho <= 20.0 && alto <= 20.0) {
      categoria = "PEQUENO";
      catCorta = "PEQ";
      tarifa = 1500;
    } else if (pesoKg <= 5.0 && largo <= 50.0 && ancho <= 50.0 && alto <= 50.0) {
      categoria = "MEDIANO";
      catCorta = "MED";
      tarifa = 2800;
    } else if (pesoKg <= LIMITE_PESO_MAX_KG &&
               largo <= LIMITE_DIMENSION_MAX_CM &&
               ancho <= LIMITE_DIMENSION_MAX_CM &&
               alto <= LIMITE_DIMENSION_MAX_CM) {
      categoria = "GRANDE";
      catCorta = "GRA";
      tarifa = 4200;
    }
  }

  // 4. Indicadores luminosos (LEDs)
  if (medicionValida && categoria != "EXCESO") {
    digitalWrite(PIN_LED_VERDE, HIGH);
    digitalWrite(PIN_LED_ROJO, LOW);
  } else {
    digitalWrite(PIN_LED_VERDE, LOW);
    digitalWrite(PIN_LED_ROJO, HIGH);
  }

  // 5. Alternar pantallas en el LCD cada 1.5 segundos
  if (millis() - tiempoPantalla >= 1500) {
    tiempoPantalla = millis();
    pagina = 1 - pagina;
    lcd.clear();
  }

  if (!medicionValida) {
    lcd.setCursor(0, 0);
    lcd.print("Esperando paquete");
    lcd.setCursor(0, 1);
    lcd.print("Coloque objeto  ");
  } else if (pagina == 0) {
    lcd.setCursor(0, 0);
    lcd.print("L:");
    lcd.print((int)largo);
    lcd.print(" A:");
    lcd.print((int)ancho);
    lcd.print(" H:");
    lcd.print((int)alto);
    lcd.print("  ");

    lcd.setCursor(0, 1);
    lcd.print("Dimensiones cm  ");
  } else {
    lcd.setCursor(0, 0);
    lcd.print("Peso:");
    lcd.print(pesoKg, 1);
    lcd.print("kg ");

    lcd.setCursor(0, 1);
    if (categoria == "EXCESO") {
      lcd.print("RECHAZADO EXCESO");
    } else {
      lcd.print(catCorta);
      lcd.print(" $");
      lcd.print(tarifa);
      lcd.print("       ");
    }
  }

  // 6. Transmisión de datos al Monitor Serie (Formato JSON)
  Serial.print("{\"largo\":");
  Serial.print(largo);
  Serial.print(",\"ancho\":");
  Serial.print(ancho);
  Serial.print(",\"alto\":");
  Serial.print(alto);
  Serial.print(",\"peso\":");
  Serial.print(pesoKg);
  Serial.print(",\"categoria\":\"");
  Serial.print(categoria);
  Serial.print("\",\"tarifa\":");
  Serial.print(tarifa);
  Serial.println("}");

  delay(100);
}